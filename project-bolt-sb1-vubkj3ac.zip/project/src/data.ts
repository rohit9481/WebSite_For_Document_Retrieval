import { Document } from './types';

export const sampleDocuments: Document[] = [
  {
    id: '1',
    title: 'Introduction to Search Algorithms',
    content: 'Search algorithms are fundamental to information retrieval systems. They enable efficient discovery of relevant information from large datasets.',
    category: 'Technical',
    dateAdded: '2024-03-15',
  },
  {
    id: '2',
    title: 'Vector Space Model',
    content: 'The Vector Space Model represents documents as vectors in a high-dimensional space, where each dimension corresponds to a term in the vocabulary.',
    category: 'Research',
    dateAdded: '2024-03-14',
  },
  {
    id: '3',
    title: 'TF-IDF Scoring',
    content: 'Term Frequency-Inverse Document Frequency (TF-IDF) is a numerical statistic intended to reflect how important a word is to a document in a collection.',
    category: 'Technical',
    dateAdded: '2024-03-13',
  },
  {
    id: '4',
    title: 'Boolean Retrieval Model',
    content: 'The Boolean retrieval model is based on Boolean algebra and set theory. Documents are retrieved based on exact matches to Boolean queries.',
    category: 'Research',
    dateAdded: '2024-03-12',
  },
];