export interface Document {
  id: string;
  title: string;
  content: string;
  category: string;
  dateAdded: string;
  fileName: string;
}

export interface SearchResult {
  document: Document;
  relevanceScore: number;
}