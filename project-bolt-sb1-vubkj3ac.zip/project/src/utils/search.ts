import { Document, SearchResult } from '../types';

export function searchDocuments(query: string, documents: Document[]): SearchResult[] {
  const searchTerms = query.toLowerCase().split(' ');
  
  return documents.map(doc => {
    const content = doc.content.toLowerCase();
    const title = doc.title.toLowerCase();
    
    // Calculate relevance score based on term frequency
    let relevanceScore = 0;
    
    searchTerms.forEach(term => {
      // Title matches are weighted more heavily
      const titleMatches = (title.match(new RegExp(term, 'g')) || []).length;
      const contentMatches = (content.match(new RegExp(term, 'g')) || []).length;
      
      relevanceScore += (titleMatches * 2) + contentMatches;
    });

    return {
      document: doc,
      relevanceScore
    };
  })
  .filter(result => result.relevanceScore > 0)
  .sort((a, b) => b.relevanceScore - a.relevanceScore);
}