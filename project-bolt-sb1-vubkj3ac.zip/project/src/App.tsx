import React, { useState, useEffect } from 'react';
import { SearchBar } from './components/SearchBar';
import { DocumentCard } from './components/DocumentCard';
import { UploadForm } from './components/UploadForm';
import { Database, Upload } from 'lucide-react';
import { SearchResult } from './types';

// Define API base URL
const API_BASE_URL = 'http://localhost:8000';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showUpload, setShowUpload] = useState(false);

  useEffect(() => {
    const fetchResults = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        return;
      }

      setIsLoading(true);
      try {
        const response = await fetch(`${API_BASE_URL}/search?q=${encodeURIComponent(searchQuery)}`);
        if (!response.ok) {
          throw new Error('Search request failed');
        }
        const data = await response.json();
        setSearchResults(data);
      } catch (error) {
        console.error('Error fetching search results:', error);
        setSearchResults([]);
      } finally {
        setIsLoading(false);
      }
    };

    const debounceTimer = setTimeout(fetchResults, 300);
    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  const handleUploadSuccess = () => {
    setShowUpload(false);
    setSearchQuery(''); // Reset search to show updated results
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Database className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">
                Document Search Engine
              </h1>
            </div>
            <button
              onClick={() => setShowUpload(!showUpload)}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Upload className="h-5 w-5 mr-2" />
              Upload Document
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showUpload ? (
          <UploadForm onUploadSuccess={handleUploadSuccess} apiBaseUrl={API_BASE_URL} />
        ) : (
          <>
            {/* Search Section */}
            <div className="flex justify-center mb-8">
              <SearchBar query={searchQuery} setQuery={setSearchQuery} />
            </div>

            {/* Results Section */}
            <div className="space-y-6">
              {isLoading ? (
                <div className="text-center py-12">
                  <p className="text-gray-600">Searching...</p>
                </div>
              ) : searchQuery.trim() === '' ? (
                <div className="text-center py-12">
                  <h2 className="text-xl font-medium text-gray-900 mb-2">
                    Welcome to Document Search
                  </h2>
                  <p className="text-gray-600">
                    Enter your search query above to find relevant documents.
                  </p>
                </div>
              ) : searchResults.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-600">
                    No documents found matching your search.
                  </p>
                </div>
              ) : (
                <>
                  <h2 className="text-lg font-medium text-gray-900">
                    Search Results ({searchResults.length})
                  </h2>
                  <div className="space-y-4">
                    {searchResults.map((result) => (
                      <DocumentCard
                        key={result.document.id}
                        document={result.document}
                        relevanceScore={result.relevanceScore}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
}

export default App;