import React from 'react';
import { FileText } from 'lucide-react';
import { Document } from '../types';

interface DocumentCardProps {
  document: Document;
  relevanceScore?: number;
}

export function DocumentCard({ document, relevanceScore }: DocumentCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
      <div className="flex items-start gap-4">
        <div className="p-2 bg-blue-100 rounded-lg">
          <FileText className="h-6 w-6 text-blue-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900">{document.title}</h3>
          <p className="mt-1 text-sm text-gray-600">{document.content}</p>
          <div className="mt-4 flex items-center gap-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              {document.category}
            </span>
            <span className="text-sm text-gray-500">
              Added: {new Date(document.dateAdded).toLocaleDateString()}
            </span>
            {relevanceScore !== undefined && (
              <span className="text-sm text-gray-500">
                Relevance: {relevanceScore.toFixed(2)}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}