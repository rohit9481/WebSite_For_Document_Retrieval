from http.server import SimpleHTTPRequestHandler, HTTPServer
import json
from urllib.parse import parse_qs, urlparse
import math
from collections import Counter
import re
import os
import uuid
from datetime import datetime
import cgi

# Ensure uploads directory exists
UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

# Load documents from storage
def load_documents():
    if os.path.exists('documents.json'):
        with open('documents.json', 'r') as f:
            return json.load(f)
    return []

# Save documents to storage
def save_documents(documents):
    with open('documents.json', 'w') as f:
        json.dump(documents, f)

# Initialize documents
documents = load_documents()
if not documents:
    # Use sample documents as initial data
    documents = [
        {
            "id": "1",
            "title": "Introduction to Search Algorithms",
            "content": "Search algorithms are fundamental to information retrieval systems. They enable efficient discovery of relevant information from large datasets.",
            "category": "Technical",
            "dateAdded": "2024-03-15",
            "fileName": "intro_search.txt"
        },
        {
            "id": "2",
            "title": "Vector Space Model",
            "content": "The Vector Space Model represents documents as vectors in a high-dimensional space, where each dimension corresponds to a term in the vocabulary.",
            "category": "Research",
            "dateAdded": "2024-03-14",
            "fileName": "vector_space.txt"
        },
        {
            "id": "3",
            "title": "TF-IDF Scoring",
            "content": "Term Frequency-Inverse Document Frequency (TF-IDF) is a numerical statistic intended to reflect how important a word is to a document in a collection.",
            "category": "Technical",
            "dateAdded": "2024-03-13",
            "fileName": "tfidf.txt"
        },
        {
            "id": "4",
            "title": "Boolean Retrieval Model",
            "content": "The Boolean retrieval model is based on Boolean algebra and set theory. Documents are retrieved based on exact matches to Boolean queries.",
            "category": "Research",
            "dateAdded": "2024-03-12",
            "fileName": "boolean_model.txt"
        }
    ]
    save_documents(documents)

def tokenize(text):
    return re.findall(r'\w+', text.lower())

def compute_tf(text):
    return Counter(tokenize(text))

def compute_idf(term, documents):
    doc_count = sum(1 for doc in documents if term in tokenize(doc["title"] + " " + doc["content"]))
    return math.log(len(documents) / (1 + doc_count))

def compute_tfidf_score(query_terms, document):
    doc_text = document["title"] + " " + document["content"]
    tf = compute_tf(doc_text)
    
    score = 0
    for term in query_terms:
        title_weight = 2.0 if term in tokenize(document["title"]) else 0.0
        tf_score = tf[term] if term in tf else 0
        idf = compute_idf(term, documents)
        score += (tf_score + title_weight) * idf
    
    return score

def extract_text_content(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

class SearchHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_cors_headers()
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        if self.path.startswith('/search'):
            parsed_url = urlparse(self.path)
            params = parse_qs(parsed_url.query)
            query = params.get('q', [''])[0]

            if not query:
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps([]).encode())
                return

            query_terms = tokenize(query)
            results = []
            
            for doc in documents:
                score = compute_tfidf_score(query_terms, doc)
                if score > 0:
                    results.append({
                        "document": doc,
                        "relevanceScore": score
                    })

            results.sort(key=lambda x: x["relevanceScore"], reverse=True)

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(results).encode())
        
        elif self.path == '/documents':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(documents).encode())
        
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == '/upload':
            content_type = self.headers.get('Content-Type')
            if not content_type or not content_type.startswith('multipart/form-data'):
                self.send_error(400, "Bad Request: Must be multipart/form-data")
                return

            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={
                    'REQUEST_METHOD': 'POST',
                    'CONTENT_TYPE': self.headers['Content-Type'],
                }
            )

            if 'file' not in form or 'title' not in form or 'category' not in form:
                self.send_error(400, "Missing required fields")
                return

            file_item = form['file']
            title = form['title'].value
            category = form['category'].value

            if not file_item.filename:
                self.send_error(400, "No file was uploaded")
                return

            file_id = str(uuid.uuid4())
            filename = os.path.join(UPLOAD_DIR, f"{file_id}_{file_item.filename}")
            
            with open(filename, 'wb') as f:
                f.write(file_item.file.read())

            content = extract_text_content(filename)
            
            new_document = {
                "id": file_id,
                "title": title,
                "content": content,
                "category": category,
                "dateAdded": datetime.now().strftime("%Y-%m-%d"),
                "fileName": os.path.basename(filename)
            }

            documents.append(new_document)
            save_documents(documents)

            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(new_document).encode())

        else:
            self.send_error(404, "Not Found")

    def send_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

def run_server():
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, SearchHandler)
    print('Starting server on port 8000...')
    httpd.serve_forever()

if __name__ == '__main__':
    run_server()